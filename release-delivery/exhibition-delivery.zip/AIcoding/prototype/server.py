from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
import json,sqlite3,uuid,os,html,threading
from urllib.parse import urlparse
from engine import DATA,ROOT,solve,move,normalize_rules
STATE=ROOT/'.local';STATE.mkdir(exist_ok=True)
LOCK=threading.Lock()
def db():
 c=sqlite3.connect(STATE/'prototype.sqlite');c.row_factory=sqlite3.Row;return c
with db() as c:
 c.execute('CREATE TABLE IF NOT EXISTS plans(id TEXT PRIMARY KEY, created TEXT DEFAULT CURRENT_TIMESTAMP, body TEXT)')
 c.execute('CREATE TABLE IF NOT EXISTS rules(id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT DEFAULT CURRENT_TIMESTAMP, body TEXT)')
def save(p):
 parent=p.get('id');p['parent']=parent;p['id']=uuid.uuid4().hex
 with db() as c:c.execute('INSERT INTO plans(id,body) VALUES(?,?)',(p['id'],json.dumps(p,ensure_ascii=False)))
 return p
def getplan(pid):
 with db() as c:row=c.execute('SELECT body FROM plans WHERE id=?',(pid,)).fetchone()
 if not row:raise ValueError('方案不存在')
 return json.loads(row['body'])
def svg(p):
 hs=DATA['halls'];zs={z['id']:z for z in p['zones']};w=1500;out=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="1640" viewBox="0 0 {w} 1640"><rect width="100%" height="100%" fill="#f3f6f9"/><g font-family="Noto Sans CJK SC, sans-serif"><text x="30" y="45" font-size="25">第139届参考 · 第{p["phase"]}期布局草案</text><text x="30" y="78" font-size="15" fill="#a45b18">逻辑展厅示意，非地理坐标图；未经安全、几何与容量模板审批</text>']
 for bi,b in enumerate('ADBC'):
  bx=30+bi*370;out.append(f'<text x="{bx}" y="115" font-size="22">{b}区</text>')
  for i,h in enumerate([x for x in hs if x['building']==b]):
   x=bx+(i%2)*175;y=135+(i//2)*130
   out.append(f'<rect x="{x}" y="{y}" width="165" height="120" rx="8" fill="white" stroke="#ced8e2"/><text x="{x+8}" y="{y+22}" font-size="16">{h["id"]} {"室外" if h["outdoor"] else "中央通道" if h["central"] else ""}</text>')
   for j,a in enumerate([a for a in p['allocations'] if a['hall']==h['id']]):
    z=zs[a['zone']];label=html.escape(z['name']);color=f'hsl({int(z["id"][1:])*47%360},58%,40%)'
    out.append(f'<rect x="{x+6}" y="{y+32+j*20}" width="153" height="19" fill="{color}"/><text x="{x+9}" y="{y+46+j*20}" font-size="10" fill="white">{label[:14]} {a["brand"]+a["general"]}</text>')
 out.append('</g></svg>');return ''.join(out)
class Handler(BaseHTTPRequestHandler):
 def respond(self,body,status=200,kind='application/json; charset=utf-8'):
  if not isinstance(body,bytes):body=(json.dumps(body,ensure_ascii=False) if kind.startswith('application/json') else body).encode()
  self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(body)));self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(body)
 def do_GET(self):
  path=urlparse(self.path).path
  try:
   if path=='/api/health':return self.respond({'ok':True,'dataset':'139-reference','halls':len(DATA['halls']),'zones':len(DATA['zones'])})
   if path=='/api/data':
    with db() as c:r=c.execute('SELECT body FROM rules ORDER BY id DESC LIMIT 1').fetchone()
    return self.respond({**DATA,'saved_rules':json.loads(r['body']) if r else DATA['default_rules']})
   if path=='/api/plans':
    with db() as c:rs=c.execute('SELECT id,created,body FROM plans ORDER BY created DESC,rowid DESC LIMIT 100').fetchall()
    return self.respond([{'id':r['id'],'created':r['created'],'phase':json.loads(r['body'])['phase']} for r in rs])
   if path.startswith('/api/plans/'):
    bits=path.split('/');p=getplan(bits[3])
    if len(bits)==5 and bits[4]=='svg':return self.respond(svg(p),kind='image/svg+xml; charset=utf-8')
    return self.respond(p)
   if path=='/':return self.respond((ROOT/'prototype/index.html').read_bytes(),kind='text/html; charset=utf-8')
   if path.startswith('/reference/'):
    name=path.rsplit('/',1)[1]
    if name not in [f'reference-page-{i}.png' for i in [1,2,3]]:return self.respond({'error':'不存在'},404)
    return self.respond((ROOT/'deliverables'/name).read_bytes(),kind='image/png')
   return self.respond({'error':'不存在'},404)
  except ValueError as e:self.respond({'error':str(e)},404)
 def do_POST(self):
  try:
   origin=self.headers.get('Origin')
   if origin and origin not in [f'http://{self.headers.get("Host")}']:return self.respond({'error':'不允许跨站写入'},403)
   n=int(self.headers.get('Content-Length','0'))
   if not 0<n<=200000:raise ValueError('请求大小无效')
   v=json.loads(self.rfile.read(n));path=urlparse(self.path).path
   if path=='/api/rules':
    r=normalize_rules(v)
    with db() as c:cur=c.execute('INSERT INTO rules(body) VALUES(?)',(json.dumps(r),));rid=cur.lastrowid
    return self.respond({'version':rid,'rules':r})
   if path=='/api/generate':
    if not LOCK.acquire(blocking=False):return self.respond({'error':'正在求解，请稍后再试'},409)
    try:p=solve(v['phase'],v.get('rules'),v.get('overrides'))
    finally:LOCK.release()
    if not p['validation']['valid']:raise ValueError('求解后独立校验失败：'+'；'.join(p['validation']['errors']))
    return self.respond(save(p))
   if path=='/api/move':return self.respond(save(move(getplan(v['id']),v['zone'],v['from'],v['to'])))
   return self.respond({'error':'不存在'},404)
  except (ValueError,KeyError,TypeError) as e:self.respond({'error':str(e)},400)
  except Exception:
   import traceback;traceback.print_exc();self.respond({'error':'内部错误，请检查服务器日志'},500)
if __name__=='__main__':
 port=int(os.environ.get('PORT','8765'));print(f'Prototype listening on loopback port {port}',flush=True)
 ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
