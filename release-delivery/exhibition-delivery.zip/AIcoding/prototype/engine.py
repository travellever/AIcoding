"""Draft allocation engine: integer counts, shared capacity, lexicographic objectives.
Not a fire-safety or geometry certification engine. No LLM fabricates coordinates.
"""
from pathlib import Path
import json,math,copy,time
import numpy as np
import highspy
from types import SimpleNamespace
from scipy.sparse import lil_matrix
ROOT=Path(__file__).resolve().parents[1]
DATA=json.loads((ROOT/'data/dataset.json').read_text())

def capacity(h,z,rules):
 if h['outdoor'] and not (z['outdoor']=='是' or z['outdoor'] is True):return None
 if '室外' in z['name'] and not h['outdoor']:return None
 if '室内' in z['name'] and h['outdoor']:return None
 if h['central']:return h['capacities'].get(z['central_size'])
 size=z['size']
 if size in h['capacities']:return h['capacities'][size]
 if rules['estimate_capacity'] and not h['outdoor'] and size=='3×4' and '3×3' in h['capacities']:
  return math.floor(h['capacities']['3×3']*9/12)
 return None

def preference(h,z,r):
 good=h['building'] in ['A','D'];wide=(h['building']=='A' and h['floor']==1) or (h['building']=='B' and h['floor'] in [1,3]) or (h['building']=='D' and h['floor']==1)
 heavy=z['volume']=='大' or z['weight']=='重' or (z['custom_ratio'] or 0)>=r['custom_threshold'] or z['power']=='是'
 cost=(3 if heavy and not good else 0)+(3 if z['crane']=='是' and not h['outdoor'] else 0)+(2 if z['fast_setup']=='是' and not wide else 0)
 if h['building']=='C' and (z['volume']=='大' or z['weight']=='重'):cost+=4
 if z['fixed_hint'] and h['id']!='6.0':cost+=4
 return cost*r['preference_weight']

def normalize_rules(v):
 r={**DATA['default_rules'],**v}
 for key,lo,hi in [('target',0,1),('custom_threshold',0,1),('preference_weight',0,100),('split_weight',0,100),('floor_weight',0,100),('max_zones',1,4)]:
  x=r[key]
  if not isinstance(x,(int,float)) or isinstance(x,bool) or not math.isfinite(x) or not lo<=x<=hi:raise ValueError('规则参数越界：'+key)
 if int(r['max_zones'])!=r['max_zones']:raise ValueError('同厅上限必须为整数')
 for key in ['estimate_capacity','brand_first']:
  if not isinstance(r[key],bool):raise ValueError('规则必须为布尔值：'+key)
 return r

def prepare_zones(phase,overrides):
 if phase not in [1,2,3]:raise ValueError('展期必须为1、2、3')
 zs=copy.deepcopy([z for z in DATA['zones'] if z['phase']==phase])
 if set(overrides)-{z['id'] for z in zs}:raise ValueError('需求编辑包含非本期展区')
 for z in zs:
  for k,v in overrides.get(z['id'],{}).items():
   if k not in ['brand','general']:raise ValueError('仅可编辑品牌/一般需求')
   if v is not None and (not isinstance(v,int) or isinstance(v,bool) or not 0<=v<=100000):raise ValueError('需求须为0至100000的整数或空值')
   z[k]=v
  z['total']=None if z['brand'] is None or z['general'] is None else z['brand']+z['general']
 return zs

def solve(phase,rules=None,overrides=None):
 start=time.monotonic();r=normalize_rules(rules or {});zs=prepare_zones(phase,overrides or {});hs=DATA['halls']
 pairs=[(zi,hi,capacity(h,z,r)) for zi,z in enumerate(zs) if z['total'] for hi,h in enumerate(hs) if capacity(h,z,r)]
 n=len(pairs);floors=sorted({(zi,h['floor']) for zi,hi,c in pairs for h in [hs[hi]]});floor_idx={k:3*n+i for i,k in enumerate(floors)}
 deficit_start=3*n+len(floors);nv=deficit_start+len(zs);rows=[];lb=[];ub=[]
 def add(items,l=-np.inf,u=np.inf):rows.append(items);lb.append(l);ub.append(u)
 for zi,z in enumerate(zs):
  ids=[i for i,p in enumerate(pairs) if p[0]==zi]
  add({i:1 for i in ids},u=z['brand'] or 0);add({n+i:1 for i in ids},u=z['general'] or 0)
  # A soft target: a nonnegative deficit absorbs shortages.
  add({**{j:1 for i in ids for j in [i,n+i]},deficit_start+zi:1},l=math.ceil((z['total'] or 0)*r['target']))
 for hi,h in enumerate(hs):
  ids=[i for i,p in enumerate(pairs) if p[1]==hi]
  add({j:1/pairs[i][2] for i in ids for j in [i,n+i]},u=1)
  add({2*n+i:1 for i in ids},u=r['max_zones'])
 for i,(zi,hi,c) in enumerate(pairs):
  add({i:1,n+i:1,2*n+i:-c},u=0)
  add({2*n+i:1,floor_idx[zi,hs[hi]['floor']]:-1},u=0)
 bounds_lo=np.zeros(nv);bounds_hi=np.ones(nv)
 for zi,z in enumerate(zs):bounds_hi[deficit_start+zi]=math.ceil((z['total'] or 0)*r['target'])
 for i,(zi,hi,c) in enumerate(pairs):bounds_hi[i]=min(zs[zi]['brand'],c);bounds_hi[n+i]=min(zs[zi]['general'],c)
 def run(objective,warm=None):
  a=lil_matrix((len(rows),nv))
  for row,items in enumerate(rows):
   for col,v in items.items():a[row,col]=v
  a=a.tocsr();solver=highspy.Highs()
  solver.setOptionValue('output_flag',False);solver.setOptionValue('threads',2)
  solver.setOptionValue('time_limit',6.0);solver.setOptionValue('mip_rel_gap',0.005)
  solver.setOptionValue('random_seed',0)
  solver.addCols(nv,objective,bounds_lo,bounds_hi,0,np.zeros(nv+1,dtype=np.int32),np.array([],dtype=np.int32),np.array([],dtype=float))
  solver.addRows(len(rows),np.array(lb),np.array(ub),len(a.data),a.indptr.astype(np.int32),a.indices.astype(np.int32),a.data)
  solver.changeColsIntegrality(nv,np.arange(nv,dtype=np.int32),np.ones(nv,dtype=np.uint8))
  if warm is not None:solver.setSolution(nv,np.arange(nv,dtype=np.int32),warm)
  solver.run();status=solver.getModelStatus();solution=solver.getSolution();info=solver.getInfo()
  code=0 if status==highspy.HighsModelStatus.kOptimal else 1 if status==highspy.HighsModelStatus.kTimeLimit else 2
  x=np.array(solution.col_value) if solution.value_valid and info.primal_solution_status==highspy.SolutionStatus.kSolutionStatusFeasible else None
  gap=info.mip_gap if math.isfinite(info.mip_gap) else None
  return SimpleNamespace(status=code,x=x,message=solver.modelStatusToString(status),mip_gap=gap)
 passes=[];result=None
 if not n:raise ValueError('没有可分配的有效需求')
 stages=['brand','total','preference'] if r['brand_first'] else ['total','preference']
 for stage in stages:
  obj=np.zeros(nv)
  if stage=='brand':obj[:n]=-1
  elif stage=='total':obj[:2*n]=-1
  else:
   for i,(zi,hi,c) in enumerate(pairs):
    obj[i]=obj[n+i]=preference(hs[hi],zs[zi],r)/max(1,c)
    obj[2*n+i]=r['split_weight']+0.001*(hi+1)
   obj[3*n:deficit_start]=r['floor_weight']
   for zi,z in enumerate(zs):obj[deficit_start+zi]=100/max(1,z['total'] or 0)
  res=run(obj,result.x if result is not None else None)
  passes.append({'stage':stage,'status':int(res.status),'incumbent':res.x is not None,'message':res.message,'gap':float(res.mip_gap) if res.mip_gap is not None else None})
  if res.x is None:
   if result is None:raise ValueError('求解器未返回可行草案：'+res.message)
   break
  result=res
  if stage!='preference':
   count=n if stage=='brand' else 2*n;value=int(np.rint(res.x[:count]).sum());add({i:1 for i in range(count)},l=value,u=value)
 allocations=[]
 for i,(zi,hi,c) in enumerate(pairs):
  b=int(round(result.x[i]));g=int(round(result.x[n+i]))
  if b+g:allocations.append({'zone':zs[zi]['id'],'hall':hs[hi]['id'],'brand':b,'general':g})
 plan=dict(phase=phase,rules=r,zones=zs,allocations=allocations,solver=passes,elapsed=round(time.monotonic()-start,2),status='DRAFT',geometry='schematic')
 plan['validation']=validate(plan);return plan

def validate(plan):
 r=plan['rules'];zs={z['id']:z for z in plan['zones']};hs={h['id']:h for h in DATA['halls']};errors=[];warnings=[];totals={z:{'brand':0,'general':0,'halls':[]} for z in zs};usage={};seen=set()
 for a in plan['allocations']:
  if a['zone'] not in zs or a['hall'] not in hs:errors.append('未知展区或展厅');continue
  z=zs[a['zone']];h=hs[a['hall']];c=capacity(h,z,r)
  if not c:errors.append(f"{z['name']}不能分配到{h['id']}");continue
  if any(not isinstance(a[k],int) or a[k]<0 for k in ['brand','general']) or a['brand']+a['general']==0:errors.append('展位数必须为非负整数且合计大于0');continue
  key=(a['zone'],a['hall'])
  if key in seen:errors.append('重复展区展厅记录')
  seen.add(key)
  u=usage.setdefault(h['id'],{'fraction':0,'zones':set()});u['fraction']+=(a['brand']+a['general'])/c;u['zones'].add(z['id'])
  for k in ['brand','general']:totals[z['id']][k]+=a[k]
  totals[z['id']]['halls'].append(h['id'])
  if not h['central'] and z['size'] not in h['capacities']:warnings.append(f"{h['id']}的{z['size']}容量为面积折算估计")
  if h['outdoor'] and len(h['capacities'])>1:warnings.append(f"{h['id']}替代规格的混用按线性占比估算，需审批容量模板")
 for hid,u in usage.items():
  if u['fraction']>1+1e-6:errors.append(f'{hid}容量超限：{u["fraction"]:.1%}')
  if len(u['zones'])>r['max_zones']:errors.append(f'{hid}混排数超限')
 stats=[]
 for zid,z in zs.items():
  t=totals[zid];assigned=t['brand']+t['general'];d=z['total']
  if d is None:warnings.append(z['name']+'需求缺失，未参与求解')
  if t['brand']>(z['brand'] or 0) or t['general']>(z['general'] or 0):errors.append(z['name']+'分配超过分类需求')
  stats.append(dict(id=zid,name=z['name'],demand=d,assigned=assigned,brand=t['brand'],general=t['general'],rate=assigned/d if d else None,shortfall=max(0,math.ceil(d*r['target'])-assigned) if d is not None else None,halls=t['halls'],floors=len({hs[x]['floor'] for x in t['halls']}),history139=z['history']['139']['total'],history134=z['history']['134']['total'],added_halls=sorted(set(t['halls'])-set(z.get('history_halls',[]))),removed_halls=sorted(set(z.get('history_halls',[]))-set(t['halls']))))
 warnings+=['缺少通道/柱子/出口坐标、消防阈值、展品数值负荷和棚下标记；未进行安全认证。','同板块相邻缺少邻接图，当前未计入优化；统计面积仅为净展位面积。']
 demand=sum(z['total'] or 0 for z in zs.values());assigned=sum(x['assigned'] for x in stats)
 return dict(valid=not errors,errors=errors,warnings=sorted(set(warnings)),stats=stats,summary={'demand':demand,'assigned':assigned,'brand':sum(x['brand'] for x in stats),'general':sum(x['general'] for x in stats),'rate':assigned/demand if demand else None,'missing':sum(z['total'] is None for z in zs.values()),'net_area':round(sum((a['brand']+a['general'])*(8.84 if hs[a['hall']]['central'] else math.prod(float(i) for i in zs[a['zone']]['size'].split('×'))) for a in plan['allocations']),2)})

def move(plan,zone,source,target):
 p=copy.deepcopy(plan)
 if source==target:raise ValueError('请选择其他展厅')
 a=next((x for x in p['allocations'] if x['zone']==zone and x['hall']==source),None)
 if a is None:raise ValueError('待移动分配不存在')
 if target not in {h['id'] for h in DATA['halls']}:raise ValueError('目标展厅不存在')
 # Central booths have different dimensions. A drag cannot silently resize booths.
 hm={h['id']:h for h in DATA['halls']}
 if hm[source]['central']!=hm[target]['central']:raise ValueError('中央通道与主展厅规格不同，请重新生成分配')
 other=next((x for x in p['allocations'] if x['zone']==zone and x['hall']==target),None)
 if other:
  other['brand']+=a['brand'];other['general']+=a['general'];p['allocations'].remove(a)
 else:a['hall']=target
 p['validation']=validate(p)
 if not p['validation']['valid']:raise ValueError('；'.join(p['validation']['errors']))
 p['change']={'zone':zone,'from':source,'to':target};return p
