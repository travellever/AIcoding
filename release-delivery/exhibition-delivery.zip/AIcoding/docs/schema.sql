-- MySQL-compatible design skeleton; adapt identifiers/FKs to the existing business schema.
-- Never execute on production without a reviewed migration.
CREATE TABLE layout_rule_version (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 rule_set_id BIGINT NOT NULL,
 version_no INT NOT NULL,
 edition INT NOT NULL,
 phase_no INT NULL,
 condition_json JSON NOT NULL,
 effect_json JSON NOT NULL,
 severity VARCHAR(12) NOT NULL,
 weight DECIMAL(12,4) NULL,
 status VARCHAR(20) NOT NULL,
 created_by BIGINT NOT NULL,
 created_at DATETIME NOT NULL,
 UNIQUE KEY uq_rule_version(rule_set_id,version_no)
);
CREATE TABLE layout_plan (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 edition INT NOT NULL,
 phase_no INT NOT NULL,
 parent_id BIGINT NULL,
 data_version VARCHAR(64) NOT NULL,
 rule_version VARCHAR(64) NOT NULL,
 geometry_version VARCHAR(64) NOT NULL,
 input_hash CHAR(64) NOT NULL,
 status VARCHAR(32) NOT NULL,
 solver_status VARCHAR(40) NOT NULL,
 revision INT NOT NULL DEFAULT 1,
 created_by BIGINT NOT NULL,
 created_at DATETIME NOT NULL,
 INDEX ix_phase(edition,phase_no,status)
);
CREATE TABLE layout_allocation (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 plan_id BIGINT NOT NULL,
 zone_id BIGINT NOT NULL,
 hall_version_id BIGINT NOT NULL,
 spec_id BIGINT NOT NULL,
 booth_type VARCHAR(16) NOT NULL,
 booth_count INT NOT NULL,
 template_id BIGINT NOT NULL,
 locked_flag TINYINT NOT NULL DEFAULT 0,
 UNIQUE KEY uq_allocation(plan_id,zone_id,hall_version_id,spec_id,booth_type),
 FOREIGN KEY(plan_id) REFERENCES layout_plan(id)
);
CREATE TABLE layout_validation_item (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 plan_id BIGINT NOT NULL,
 rule_code VARCHAR(64) NOT NULL,
 scope_json JSON NOT NULL,
 result_status VARCHAR(24) NOT NULL,
 evidence_json JSON NOT NULL,
 FOREIGN KEY(plan_id) REFERENCES layout_plan(id)
);
CREATE TABLE layout_job (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 idempotency_key VARCHAR(96) NOT NULL UNIQUE,
 input_hash CHAR(64) NOT NULL,
 input_snapshot JSON NOT NULL,
 result_plan_id BIGINT NULL,
 status VARCHAR(40) NOT NULL,
 solver_details JSON NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL
);
