# 展序 · AI辅助展区布局

依据上传的readme及五份业务附件完成的需求分析、量化规则、系统设计与可运行评审原型。后端正式接入路线保留Spring Boot / Java8；前端沿用Vue2/3，独立Python负责优化，SVG承担交互和出图。

- [需求分析与量化规则](docs/01-需求分析与量化规则.md)：数据审计、功能验收、H/S规则目录、公式与缺口。
- [系统设计与技术路线](docs/02-系统设计与技术路线.md)：架构、数据模型、求解、编辑、接口、同步和出图。
- [原型说明与验收](docs/03-原型说明与验收.md)：操作、实现边界和测试。
- [设计表结构骨架](docs/schema.sql)。
- `data/raw/`保存原始附件，`dataset.json`保存来源可追溯的规范化数据。
- `deliverables/`保存三期草案SVG/JSON、历史PDF页面、评审Word文档、规则表及验证报告。

```bash
cd /workspace/AIcoding
bash tools/setup.sh
.venv/bin/python prototype/server.py
```

当前云机器已准备Python虚拟环境。默认回环端口8765；不提供云入门界面不支持的本地预览链接。运行进程不随环境快照恢复，后续任务应按保存的启动说明重启。

```bash
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python tools/validate.py
```

全部方案为DRAFT，逻辑示意不等于批准的地理/消防图。用户确认满足率为软目标、同厅优先单展区可混排。集成房屋需求缺失、底图/安全数值/容量模式待确认，详见文档。原型未访问用户Windows本地demo，也未集成未提供源码的现有业务系统。
