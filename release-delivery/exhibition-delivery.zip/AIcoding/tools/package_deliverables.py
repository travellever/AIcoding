from pathlib import Path
import re,json,zipfile
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
R=Path(__file__).resolve().parents[1];O=R/'deliverables'
def clean(s):return s.replace('**','').replace('`','')
doc=Document();sec=doc.sections[0];sec.header.paragraphs[0].text='展序 / AI辅助展区布局 / 业务评审稿'
style=doc.styles['Normal'];style.font.name='Calibri';style.font.size=Pt(10);style._element.rPr.rFonts.set(qn('w:eastAsia'),'宋体')
for name in ['Title','Heading 1','Heading 2','Heading 3']:
 doc.styles[name]._element.rPr.rFonts.set(qn('w:eastAsia'),'微软雅黑')
doc.add_heading('AI辅助展区布局\n需求分析、规则量化与系统设计',0)
doc.add_paragraph('业务评审稿 v1.0 | 2026年10月22日')
doc.add_paragraph('基于6份用户上传文件。满足率为软目标；优先同厅单展区、允许必要混排。原型为逻辑布局草案，容量估算、安全缺失与限时求解状态均已明示。')
doc.add_paragraph('交付内容：需求分析与规则目录 / 系统设计与集成路线 / 原型说明与验收 / 数据与验证成果。完整可运行代码与原始附件随交付包提供。')
for f in sorted((R/'docs').glob('*.md')):
 doc.add_page_break();lines=f.read_text().splitlines();i=0;code=False
 while i<len(lines):
  line=lines[i]
  if line.startswith('```'):code=not code;i+=1;continue
  if line.startswith('|') and not code:
   rows=[]
   while i<len(lines) and lines[i].startswith('|'):
    row=[clean(x.strip()) for x in lines[i].strip('|').split('|')]
    if not all(re.fullmatch(r'[:\- ]+',x) for x in row):rows.append(row)
    i+=1
   if rows:
    n=max(map(len,rows));t=doc.add_table(rows=1,cols=n);t.style='Light Shading Accent 1'
    for j,v in enumerate(rows[0]):t.rows[0].cells[j].text=v
    for row in rows[1:]:
     cells=t.add_row().cells
     for j,v in enumerate(row):cells[j].text=v
    for row in t.rows:
     for cell in row.cells:
      for p in cell.paragraphs:
       for run in p.runs:run.font.size=Pt(8)
   continue
  if line.startswith('#') and not code:
   level=len(line)-len(line.lstrip('#'));doc.add_heading(clean(line[level:].strip()),min(level,3))
  elif line.strip():
   p=doc.add_paragraph(clean(line))
   if code:
    for run in p.runs:run.font.name='Consolas';run.font.size=Pt(8)
  i+=1
reports=json.loads((O/'validation.json').read_text())
doc.add_page_break();doc.add_heading('附：本实例真实数据验证',1)
t=doc.add_table(rows=1,cols=6);t.style='Light Shading Accent 1'
for c,v in zip(t.rows[0].cells,['展期','已知需求','分配','品牌分配','满足率','缺失需求条数']):c.text=v
for r in reports:
 s=r['summary'];vals=[r['phase'],s['demand'],s['assigned'],s['brand'],f'{s["rate"]:.2%}',s['missing']]
 for c,v in zip(t.add_row().cells,vals):c.text=str(v)
doc.add_paragraph('三期均通过当前已实现的独立约束校验。品牌层和总量层取得最优解；偏好层为限时可行解，未证明全局最优。容量折算及缺失的安全数据意味着结果仍为DRAFT。详细状态和gap见validation.json。')
doc.save(O/'需求分析与系统设计-评审稿.docx')
data=json.loads((R/'data/dataset.json').read_text());wb=Workbook();wb.remove(wb.active)
def sheet(name,keys,rows):
 s=wb.create_sheet(name);s.append(keys)
 for row in rows:s.append([json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for v in row])
 s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
 for c in s[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='176650')
 for col in s.columns:
  letter=col[0].column_letter;s.column_dimensions[letter].width=min(65,max(16,max(len(str(c.value or '')) for c in col[:30])+2))
 for row in s.iter_rows(min_row=2):
  for c in row:c.alignment=Alignment(vertical='top',wrap_text=True)
 s.sheet_view.zoomScale=85
rules=[]
for line in (R/'docs/01-需求分析与量化规则.md').read_text().splitlines():
 if re.match(r'\|[HS]\d\d\|',line):rules.append([x.strip() for x in line.strip('|').split('|')])
sheet('量化规则',['ID','级别与范围','公式与执行解释','参数来源','缺失处理'],rules)
features=[]
for line in (R/'docs/01-需求分析与量化规则.md').read_text().splitlines():
 if line.startswith('|FR'):features.append(line.strip('|').split('|'))
sheet('功能验收',['编号','功能','验收标准'],features)
keys=list(data['halls'][0]);sheet('展厅规范化',keys,[[h.get(k) for k in keys] for h in data['halls']])
keys=list(data['zones'][0]);sheet('展区与需求',keys,[[z.get(k) for k in keys] for z in data['zones']])
sheet('数据审计',['问题码','展区','原始值','来源'],[[x['code'],x['zone'],x.get('value'),x['source']] for x in data['issues']])
sheet('来源完整性',['文件','SHA256'],[[s['file'],s['sha256']] for s in data['sources']])
sheet('三期结果',['展期','需求','分配','品牌','一般','满足率','净展位面积','缺失需求'],[[r['phase']]+[r['summary'][k] for k in ['demand','assigned','brand','general','rate','net_area','missing']] for r in reports])
wb.save(O/'量化规则与数据审计.xlsx')
print('Generated Word review and rule/audit workbook')
