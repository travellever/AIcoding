from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'prototype'))
from engine import solve,DATA
from server import svg
reports=[]
for phase in [1,2,3]:
 p=solve(phase);assert p['validation']['valid'],p['validation']['errors']
 (root/f'deliverables/phase-{phase}-draft.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
 (root/f'deliverables/phase-{phase}-draft.svg').write_text(svg(p))
 reports.append({'phase':phase,'summary':p['validation']['summary'],'solver':p['solver'],'elapsed':p['elapsed']})
 print(json.dumps(reports[-1],ensure_ascii=False),flush=True)
(root/'deliverables/validation.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2))
