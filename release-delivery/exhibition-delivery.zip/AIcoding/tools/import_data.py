"""Read source workbooks without rewriting them; keep exact cell provenance."""
from pathlib import Path
import json,re,hashlib
from openpyxl import load_workbook
ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'data/raw'
def sheet(name):
 s=load_workbook(RAW/name,data_only=True).active
 values={(c.row,c.column):c.value for row in s for c in row}
 for m in s.merged_cells.ranges:
  v=values[m.min_row,m.min_col]
  for r in range(m.min_row,m.max_row+1):
   for c in range(m.min_col,m.max_col+1):values[r,c]=v
 return s,lambda r,c:values.get((r,c))
def num(v):return v if isinstance(v,(int,float)) else None
def sizes(v):return [x.strip() for x in str(v).replace('x','×').split('；')]
s,get=sheet('附件1-展馆各展厅技术参数.xlsx');halls=[]
for r in range(4,61):
 id=str(get(r,2));central='中央通道' in id
 if central:id=id.split('（')[0]+'Y'
 specs=sizes(get(r,3));caps=[int(x) for x in str(get(r,4)).split('；')]
 halls.append(dict(id=id,building=get(r,1),floor=int(id.split('.')[1].replace('Y','')),outdoor=id in ['4.0','5.0','6.0','8.0','9.0','12.0','13.0'],central=central,capacities=dict(zip(specs,caps)),area=num(get(r,6)),load=num(get(r,11)),height=str(get(r,8)) if get(r,8)!=None else None,power=num(get(r,16)),water=get(r,18),gas=get(r,19),build_height=get(r,9),entry=get(r,10),columns=num(get(r,12)),roofed=None,source=f'附件1!B{r}:U{r}'))
s,get=sheet('附件2-展区设置.xlsx');_,hist=sheet('展位需求历史数据参考.xlsx');zones=[]
for r in range(4,61):
 phase={'第一期':1,'第二期':2,'第三期':3}[get(r,1)]
 z=dict(id=f'Z{r-3:02d}',phase=phase,group=get(r,2),name=get(r,3),size=sizes(get(r,4))[0].split('、')[0],central_size=get(r,6),total=num(get(r,8)),general=num(get(r,9)),brand=num(get(r,10)),target=1.0,raw_rate=num(get(r,11)),raw_general_rate=num(get(r,12)),volume=get(r,18),height=get(r,19),weight=get(r,20),fragile=get(r,21),water=get(r,22),power=get(r,23),gas=get(r,24),hazard=get(r,25),custom_ratio=num(get(r,26)),outdoor=get(r,28),fixed_hint=get(r,29),forklift=get(r,30),crane=get(r,31),fast_setup=get(r,32),priority=get(r,15),source=f'附件2!A{r}:AF{r}',history={'139':{'total':num(hist(r,4)),'general':num(hist(r,5)),'brand':num(hist(r,6)),'raw_rate':num(hist(r,7))},'134':{'total':num(hist(r,9)),'general':num(hist(r,10)),'brand':num(hist(r,11)),'raw_rate':num(hist(r,12))}})
 zones.append(z)
rules=dict(target=1.0,custom_threshold=0.7,preference_weight=5,split_weight=20,floor_weight=15,max_zones=2,estimate_capacity=True,brand_first=True)
issues=[{'code':'MISSING_DEMAND','zone':z['name'],'source':z['source']} for z in zones if z['total'] is None]
issues += [{'code':'HISTORICAL_RATE_GT_1','zone':z['name'],'value':z['raw_rate'],'source':z['source']} for z in zones if z['raw_rate'] and z['raw_rate']>1]
data=dict(halls=halls,zones=zones,default_rules=rules,issues=issues,sources=[dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(RAW.iterdir())])
(ROOT/'data/dataset.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
print(json.dumps({'halls':len(halls),'zones':len(zones),'phase_demand':{p:sum(z['total'] or 0 for z in zones if z['phase']==p) for p in [1,2,3]},'missing':issues[:1]},ensure_ascii=False))
