#!/usr/bin/env bash
set -euo pipefail
cd /workspace/AIcoding
export UV_CACHE_DIR=/workspace/.cache/uv
if [ ! -x .venv/bin/python ]; then uv venv .venv --python python3.12; fi
uv pip install --python .venv/bin/python -r requirements.txt
# Imported source snapshots are versioned deliverables. Setup never rewrites them.
.venv/bin/python - <<'CHECK'
import json
from pathlib import Path
p=Path('data/dataset.json')
d=json.loads(p.read_text())
assert len(d['halls'])==57 and len(d['zones'])==57
print('Dataset snapshot validated: 57 spaces, 57 zone records')
CHECK
