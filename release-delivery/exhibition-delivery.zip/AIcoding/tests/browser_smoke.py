"""Integration check using the cloud image's Playwright and Chromium."""
from pathlib import Path
import json,urllib.request,urllib.error,time
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];BASE='http://127.0.0.1:8765';events=[]
def request(path,body=None):
 raw=json.dumps(body).encode() if body is not None else None
 req=urllib.request.Request(BASE+path,data=raw,headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=60) as res:return json.load(res)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1600,'height':1100},device_scale_factor=1)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(BASE);page.wait_for_function('window.document.querySelectorAll(".hall").length===57')
 assert request('/api/health')['zones']==57;events.append('页面加载、57个空间、57条展区源数据正常')
 page.locator('#all').click();page.wait_for_function('document.querySelector("#all").disabled === false',timeout=90000)
 saved=request('/api/plans');assert {v['phase'] for v in saved}=={1,2,3}
 full={v['phase']:v['id'] for v in reversed(saved)}
 for phase,pid in full.items():
  plan=request('/api/plans/'+pid);assert plan['validation']['valid'];assert all(s['incumbent'] for s in plan['solver'])
 events.append('浏览器按钮生成三个展期，API独立读取每期已保存方案，均通过容量/需求/兼容校验')
 page.locator('[data-rule=custom_threshold]').fill('0.65')
 page.locator('[data-rule=custom_threshold]').dispatch_event('change')
 with page.expect_response('**/api/rules') as result:page.locator('#save-rules').click()
 assert result.value.status==200;events.append('规则参数修改并保存新版本成功')
 for view in ['demand','history','issues','statistics']:
  page.locator(f'[data-view={view}]').click();assert page.locator('#'+view).is_visible()
 events.append('需求、历史原图、缺口与统计四个视图切换正常')
 page.locator('[data-p="1"]').click()
 data=request('/api/data');zs=[z for z in data['zones'] if z['phase']==1]
 overrides={z['id']:{'brand':0,'general':0} for z in zs};overrides['Z01']={'brand':10,'general':20}
 sparse=request('/api/generate',{'phase':1,'overrides':overrides});assert sparse['validation']['summary']['assigned']==30
 page.reload();page.wait_for_function('document.querySelectorAll(".zone").length>0')
 allocation=sparse['allocations'][0];target='2.1' if allocation['hall']!='2.1' else '3.1'
 source=page.locator(f'.zone[data-zone="Z01"][data-from="{allocation["hall"]}"]')
 with page.expect_response('**/api/move') as result:source.drag_to(page.locator(f'.hall[data-hall="{target}"]'))
 moved=result.value.json();assert result.value.status==200;assert moved['validation']['summary']['assigned']==30;assert moved['parent']==sparse['id']
 events.append('浏览器真实拖拽成功、计数守恒、父子版本保存成功')
 page.wait_for_function(f'document.querySelector(".zone[data-from=\\"{target}\\"]")!==null')
 page.locator('#undo').click();page.wait_for_function(f'document.querySelector(".zone[data-from=\\"{allocation["hall"]}\\"]")!==null')
 events.append('回到上一版本恢复源展厅成功')
 page.locator('#move-source').select_option('Z01|'+allocation['hall']);page.locator('#move-target').select_option('4.0')
 with page.expect_response('**/api/move') as result:page.locator('#move').click()
 assert result.value.status==400;assert '不能分配' in result.value.json()['error'];events.append('移动到不兼容室外被拒绝，当前版本保持不变')
 with page.expect_download() as d:page.locator('#export').click()
 assert d.value.suggested_filename.endswith('.svg');events.append('SVG下载成功')
 page.locator('#versions').select_option(full[1]);page.wait_for_function('document.querySelectorAll(".zone").length>20')
 page.screenshot(path=str(ROOT/'deliverables/prototype-screenshot.png'),full_page=True)
 assert not errors,errors;events.append('无浏览器脚本错误；完整画面截图已保存')
 browser.close()
(ROOT/'deliverables/browser-results.json').write_text(json.dumps({'passed':events,'browser_errors':errors},ensure_ascii=False,indent=2))
print(json.dumps(events,ensure_ascii=False,indent=2))
