import sys,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'prototype'))
from engine import DATA,validate,move,normalize_rules,prepare_zones,capacity
class RulesTest(unittest.TestCase):
 def setUp(self):
  self.plan={'phase':1,'rules':DATA['default_rules'].copy(),'zones':prepare_zones(1,{}),'allocations':[{'zone':'Z01','hall':'1.1','brand':10,'general':20}]}
 def test_source_integrity(self):
  self.assertEqual(len(DATA['halls']),57);self.assertEqual(len(DATA['zones']),57)
  for z in DATA['zones']:
   if z['total'] is not None:self.assertEqual(z['total'],z['brand']+z['general'])
  self.assertEqual([sum(z['total'] or 0 for z in DATA['zones'] if z['phase']==p) for p in [1,2,3]],[24835,24226,23631])
 def test_zero_and_unknown(self):
  self.assertIsNone(next(z for z in DATA['zones'] if z['id']=='Z34')['total'])
  self.assertEqual(DATA['zones'][-1]['total'],0)
 def test_capacity_cannot_be_exceeded(self):
  self.plan['allocations'][0]['general']=597
  self.assertFalse(validate(self.plan)['valid'])
 def test_combined_capacity(self):
  self.plan['allocations']=[{'zone':'Z01','hall':'1.1','brand':0,'general':400},{'zone':'Z02','hall':'1.1','brand':0,'general':300}]
  self.assertTrue(any('容量超限' in s for s in validate(self.plan)['errors']))
 def test_soft_target_does_not_require_100_percent(self):
  self.assertTrue(validate(self.plan)['valid'])
  self.plan['rules']['target']=0.01
  self.assertTrue(validate(self.plan)['valid'])
 def test_move_conserves_counts_and_parent(self):
  new=move(self.plan,'Z01','1.1','2.1')
  self.assertEqual(new['allocations'][0]['general'],20)
  self.assertEqual(self.plan['allocations'][0]['hall'],'1.1')
 def test_move_rejects_outdoor_and_capacity(self):
  with self.assertRaisesRegex(ValueError,'不能分配'):move(self.plan,'Z01','1.1','4.0')
  self.plan['allocations'].append({'zone':'Z02','hall':'2.1','brand':0,'general':590})
  with self.assertRaisesRegex(ValueError,'容量超限'):move(self.plan,'Z01','1.1','2.1')
 def test_central_not_silently_resized(self):
  with self.assertRaisesRegex(ValueError,'规格不同'):move(self.plan,'Z01','1.1','1.1Y')
 def test_invalid_input(self):
  for r in [{'target':float('nan')},{'max_zones':1.5},{'estimate_capacity':'yes'}]:
   with self.assertRaises(ValueError):normalize_rules(r)
  with self.assertRaises(ValueError):prepare_zones(1,{'Z01':{'brand':-1}})
 def test_strict_capacity_drops_unknown_spec(self):
  hall=DATA['halls'][0];zone=next(z for z in DATA['zones'] if z['name']=='工程机械（室内）')
  self.assertGreater(capacity(hall,zone,DATA['default_rules']),0)
  self.assertIsNone(capacity(hall,zone,{**DATA['default_rules'],'estimate_capacity':False}))
if __name__=='__main__':unittest.main()
