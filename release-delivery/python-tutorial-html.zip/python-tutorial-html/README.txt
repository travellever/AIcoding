ESP32-S3 MicroPython Tutorial - English HTML Edition

OPEN THE TUTORIAL
Extract the ZIP, then open python-tutorial.html in Chrome, Edge or Firefox.
All images, styles and scripts are embedded in this single HTML file.
No network connection, Python installation or other dependencies are required.
Download the HTML from GitHub before opening it; GitHub displays source code.

READER FEATURES
Contents: jump to chapters, projects and individual steps.
Search: find chapter names, technical terms or code keywords. Clear the search
or press Escape in the search field to restore the full tutorial.
Images: click to enlarge, browse previous/next images, and toggle actual size.
Press Escape to close the image viewer.
Code: use Copy to copy selectable code text.
Text size: use A-/A+ in the top bar.
Printing: choose Print / Save PDF to use your browser's print dialog.
Mobile: use Contents in the top bar to open or close navigation.

CONTENT
The original English text follows the tutorial's learning sequence.
The homepage, navigation, controls, image captions and dynamic messages
are now entirely in English.
The example root folder is ESP32_S3_Board; use your local materials folder.
Referenced drivers, firmware and external project source packages were not
supplied with the PDF and are not included in this HTML package.
Specified branding, logos, contact details, promotions and copyright notices
have been removed. Original PDFs and uncleaned images are not included.

VALIDATION
99 retained source pages, 95 outline topics and 139 illustrations.
All reader HTML text, attributes and dynamic strings were checked for
Chinese characters; none remain. Desktop and mobile interactions passed
browser checks in offline mode. Images and code are unchanged by this
English interface update.
All final illustrations were previously checked with OCR. Main LED, BLE,
Station, AP and TCP Server programs passed Python syntax parsing.
Hardware execution was not performed. Check your board model and pinout
before following wiring diagrams; some source illustrations show different
board designs. See validation-report.json for details.
