"""Optional: rebuild index.html from src, using only Python's standard library."""
from pathlib import Path
import json
r=Path(__file__).resolve().parent;s=r/'src'
seed=json.dumps(json.loads((s/'seed.json').read_text()),ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
html=(s/'shell.html').read_text().replace('/* STYLE */',(s/'style.css').read_text()).replace('/* SEED */',seed).replace('/* APP */',(s/'app.js').read_text())
(r/'index.html').write_text(html)
print('Rebuilt self-contained index.html')
